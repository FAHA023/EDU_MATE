<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <div class="container mt-5">
        <h1>About Us</h1>
        <p>This is the About Us page.</p>
        <a href="/" class="btn btn-primary mt-3">Back to Home</a>
    </div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\EDU_MATE\resources\views/about.blade.php ENDPATH**/ ?>