<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-5">
    <h2>Register As:</h2>
    <a href="/register/student" class="btn btn-info me-3">Student</a>
    <a href="/register/tutor" class="btn btn-success">Tutor</a>
</body>
</html>
